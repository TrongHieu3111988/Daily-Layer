Christmas Cookie Cutter Set (3 shapes)

Print tips: Print as shown, flange down on the bed: no supports, no brim. 0.2 mm layers, 3 walls, 100% of the wall is solid. Each cutter is 14 mm tall with a 2 mm pusher flange; flip it over to cut. For dough and play dough: hand wash in lukewarm water, keep it off the dishwasher. PLA is not guaranteed food safe, so for real cookies use a food-safe filament or press through baking paper. Not a toy for children under 3.

License: personal use. Commercial sale of prints requires a Pro membership.
