Gyro Rings Fidget

Print tips: Print as one plate, 0.16 mm layer, no supports, 0.6 mm clearance; twist gently to free rings

License: personal use. Commercial sale of prints requires a Pro membership.
