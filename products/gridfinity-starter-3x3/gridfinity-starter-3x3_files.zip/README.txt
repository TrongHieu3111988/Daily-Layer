Gridfinity Starter Set 3×3

Print tips: Gridfinity-compatible (42 mm grid, 7 mm units), lite profile without stacking lip. 0.2 mm layer, 2 walls, no supports. Baseplate is open-bottom to save filament.

License: personal use. Commercial sale of prints requires a Pro Seller membership.
